from .metrics import averageMeter, runningScore
from .log import get_logger

from .optim.AdamW import AdamW
from .optim.Lookahead import Lookahead
from .optim.RAdam import RAdam
from .optim.Ranger import Ranger

from .losses.loss import CrossEntropyLoss2d, CrossEntropyLoss2dLabelSmooth, \
    ProbOhemCrossEntropy2d, FocalLoss2d, LovaszSoftmax, LDAMLoss, MscCrossEntropyLoss

from .utils import ClassWeight, save_ckpt, load_ckpt, class_to_RGB, \
    compute_speed, setup_seed, group_weight_decay


# 加载数据集
def get_dataset(cfg):
    assert cfg['dataset'] in ['animal','cunluo','liuyu']

    if cfg['dataset'] == 'animal':
        from .datasets.animal import Animal
        return Animal(cfg, mode='train', do_aug=True), Animal(cfg, mode='test')
    elif cfg['dataset'] == 'cunluo':
        from .datasets.cunluo import Cunluo
        return Cunluo(cfg, mode='train', do_aug=True), Cunluo(cfg, mode='test')
    elif cfg['dataset'] == 'liuyu':
        from .datasets.liuyu import Liuyu
        return Liuyu(cfg, mode='train', do_aug=True), Liuyu(cfg, mode='test')




def get_model(cfg):
    # 根据配置文件里的model_name标签，匹配相应模型文
    if cfg['model_name'] == 'segFormer_ModelNet':
        from toolbox.models.segFormer_ModelNet.model import segformer_ModelNet
        return segformer_ModelNet()

    elif cfg['model_name'] == 'segformer_Modelb0RDNet':
        from toolbox.models.paper2Model.model import segformer_Modelb0RDNet
        return segformer_Modelb0RDNet()
    elif cfg['model_name'] == 'segformer_Modelb5RDNet':
        from toolbox.models.paper2Model.model import segformer_Modelb5RDNet
        return segformer_Modelb5RDNet()
    elif cfg['model_name'] == 'resnet152_twoModal_ModelNet':
        from toolbox.models.paper2Model.model import resnet152_twoModal_ModelNet
        return resnet152_twoModal_ModelNet()
    elif cfg['model_name'] == 'vgg19_twoModal_ModelNet':
        from toolbox.models.paper2Model.model import vgg19_twoModal_ModelNet
        return vgg19_twoModal_ModelNet()
    elif cfg['model_name'] == 'convnext_large_twoModal_ModelNet':
        from toolbox.models.paper2Model.model import convnext_large_twoModal_ModelNet
        return convnext_large_twoModal_ModelNet()

    elif cfg['model_name'] == 'swin_b_twoModal_ModelNet':
        from toolbox.models.paper2Model.model import swin_b_twoModal_ModelNet
        return swin_b_twoModal_ModelNet()
    elif cfg['model_name'] == 'vit_b_32_twoModal_ModelNet':
        from toolbox.models.paper2Model.model import vit_b_32_twoModal_ModelNet
        return vit_b_32_twoModal_ModelNet()
