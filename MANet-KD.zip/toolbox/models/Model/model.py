# -*- encoding:utf-8 -*-

import torch
import torch.nn as nn
from toolbox.models.paper2Model.mix_transformer import mit_b0,mit_b5
class segformer_Modelb0RDNet(nn.Module):
    def __init__(self, classNum=6,channel=64):
        super(segformer_Modelb0RDNet, self).__init__()
        # Backbone model
        self.rgb = mit_b0(classNum=classNum)  # True 64, 128, 320, 512
        self.rgb1 = mit_b0(classNum=classNum)
        self.rgb.init_weights("/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/segformer/pretrained/mit_b0.pth")
        self.rgb1.init_weights("/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/segformer/pretrained/mit_b0.pth")
        #
        # self.conv1_1=nn.Conv2d(512, 1,kernel_size=1, stride=1, bias=False)
        self.MCSM=nn.MultiheadAttention(256,8)
        self.MCSM1 = nn.MultiheadAttention(256, 8)

        self.avgpoolf=nn.AdaptiveAvgPool2d((1,1))
        self.head = nn.Linear(256, 6)

    def forward(self, x,x1):

        # x = self.rgb.forward_features(x)
        x, outs = self.rgb.forward_features(x,flagSingle=False)
        x1, outs1 = self.rgb1.forward_features(x1,flagSingle=False)
        #print(outs1[-1].shape)
        b,c,h,w=outs[-1].shape
        a,aw=self.MCSM(outs[-1].reshape(b,c,h*w).permute(0,2,1),outs1[-1].reshape(b,c,h*w).permute(0,2,1),outs1[-1].reshape(b,c,h*w).permute(0,2,1))
        a1, aw1 = self.MCSM1(outs1[-1].reshape(b,c,h*w).permute(0,2,1), outs[-1].reshape(b,c,h*w).permute(0,2,1), outs[-1].reshape(b,c,h*w).permute(0,2,1))
        af=a+a1

        af=af.permute(0,2,1).reshape(b,c,h,w)
        # print(af.shape)
        af=self.avgpoolf(af).reshape(b, -1)

        af=self.head(af)

        #print(af.shape)
        return af

    def forward_features(self, x,x1):
        x, outs = self.rgb.forward_features(x, flagSingle=False)
        x1, outs1 = self.rgb1.forward_features(x1, flagSingle=False)
        return outs[-1],outs1[-1]


class segformer_Modelb5RDNet(nn.Module):
    def __init__(self, classNum=6,channel=64):
        super(segformer_Modelb5RDNet, self).__init__()
        # Backbone model
        self.rgb = mit_b5(classNum=classNum)  # True 64, 128, 320, 512
        self.rgb1 = mit_b5(classNum=classNum)
        self.rgb.init_weights("/home/wby/Desktop/whp_RGBTsemanticsegmentation/toolbox/models/DSAssistantNet/segformer/pretrained/mit_b5.pth")
        self.rgb1.init_weights("/home/wby/Desktop/whp_RGBTsemanticsegmentation/toolbox/models/DSAssistantNet/segformer/pretrained/mit_b5.pth")
        #
        # self.conv1_1=nn.Conv2d(512, 1,kernel_size=1, stride=1, bias=False)
        self.MCSM=nn.MultiheadAttention(512,8)
        self.MCSM1 = nn.MultiheadAttention(512, 8)

        self.avgpoolf=nn.AdaptiveAvgPool2d((1,1))
        self.head = nn.Linear(512, 6)

    def forward(self, x,x1):

        # x = self.rgb.forward_features(x)
        x, outs = self.rgb.forward_features(x,flagSingle=False)
        x1, outs1 = self.rgb1.forward_features(x1,flagSingle=False)
        #print(outs1[-1].shape)
        b,c,h,w=outs[-1].shape
        #print(b,c,h,w)
        a,aw=self.MCSM(outs[-1].reshape(b,c,h*w).permute(0,2,1),outs1[-1].reshape(b,c,h*w).permute(0,2,1),outs1[-1].reshape(b,c,h*w).permute(0,2,1))
        a1, aw1 = self.MCSM1(outs1[-1].reshape(b,c,h*w).permute(0,2,1), outs[-1].reshape(b,c,h*w).permute(0,2,1), outs[-1].reshape(b,c,h*w).permute(0,2,1))
        af=a+a1

        af=af.permute(0,2,1).reshape(b,c,h,w)
        # print(af.shape)
        af=self.avgpoolf(af).reshape(b, -1)

        af=self.head(af)

        #print(af.shape)
        return af

    def forward_features(self, x,x1):
        x, outs = self.rgb.forward_features(x, flagSingle=False)
        x1, outs1 = self.rgb1.forward_features(x1, flagSingle=False)
        return outs[-1],outs1[-1]



import torchvision.models as models
class resnet152_twoModal_ModelNet(nn.Module):
    def __init__(self, channel=64):
        super(resnet152_twoModal_ModelNet, self).__init__()
        # Backbone model
        self.rgb = models.resnet152(num_classes=4,pretrained=False)  # True 64, 128, 320, 512
        self.rgb1 = models.resnet152(num_classes=4, pretrained=False)

        self.MCSM=nn.MultiheadAttention(2048,8)
        self.MCSM1 = nn.MultiheadAttention(2048, 8)

        self.avgpoolf=nn.AdaptiveAvgPool2d((1,1))
        self.head = nn.Linear(2048, 6)
        #self.rgb.init_weights("/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/segformer/pretrained/mit_b4.pth")
        #path = "/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/resnet152-b121ed2d.pth"
        #self.rgb.load_state_dict(torch.load(path, map_location='cuda:0'))

        # Components of DEM module
        # self.atten_depth_channel_1 = ChannelAttention(64)
        # self.atten_depth_channel_2 = ChannelAttention(128)
        # self.atten_depth_channel_3_1 = ChannelAttention(256)
        # self.atten_depth_channel_4_1 = ChannelAttention(512)
        #
        # self.atten_depth_spatial_1 = SpatialAttention()
        # self.atten_depth_spatial_2 = SpatialAttention()
        # self.atten_depth_spatial_3_1 = SpatialAttention()
        # self.atten_depth_spatial_4_1 = SpatialAttention()
        #
        # self.conv1_1=nn.Conv2d(512, 1,kernel_size=1, stride=1, bias=False)

    def forward(self, x,x1):

        # x = self.rgb.forward_features(x)
        x=self.forward_features(x,x1)

        #print(rgb_depth[0].shape)

        # x1 = x[0]
        #
        # sx1, sx1_depth = nn.Sigmoid()(sx1),nn.Sigmoid()(sx1_depth)
        #
        # x2 = x[1]
        #
        # sx2, sx2_depth = nn.Sigmoid()(sx2), nn.Sigmoid()(sx2_depth)
        #
        # x3_1 = x[2]
        # sx3, sx3_depth = nn.Sigmoid()(sx3), nn.Sigmoid()(sx3_depth)
        #
        #
        # x4_1 = x[3]
        # sx4, sx4_depth = nn.Sigmoid()(sx4), nn.Sigmoid()(sx4_depth)
        #
        #
        # #x = x + temp0
        # x1_1 = sx1*x1 + sx1_depth*x1_depth
        # x2_1 = sx2*x2 + sx2_depth*x2_depth
        # x3_1 = sx3*x3_1 + sx3_depth*x3_1_depth
        # x4_1 = sx4*x4_1 + sx4_depth*x4_1_depth
        # x4_2 = self.rfb4_1(x4_1)
        #
        # # produce final saliency map by decoder2
        # y = self.agg1(x4_2,x4_1,x3_1,x2_1, x1_1)

        return x

    def forward_features(self,x,x1,flag=True):
        x = self.rgb.conv1(x)
        x = self.rgb.bn1(x)
        x = self.rgb.relu(x)
        x = self.rgb.maxpool(x)

        x = self.rgb.layer1(x)
        x = self.rgb.layer2(x)
        x = self.rgb.layer3(x)
        x = self.rgb.layer4(x)

        x1 = self.rgb1.conv1(x1)
        x1 = self.rgb1.bn1(x1)
        x1 = self.rgb1.relu(x1)
        x1 = self.rgb1.maxpool(x1)

        x1 = self.rgb1.layer1(x1)
        x1 = self.rgb1.layer2(x1)
        x1 = self.rgb1.layer3(x1)
        x1 = self.rgb1.layer4(x1)

        b, c, h, w = x.shape
        # print(b,c,h,w)
        a, aw = self.MCSM(x.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1))
        a1, aw1 = self.MCSM1(x1.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1))
        af = a + a1

        af = af.permute(0, 2, 1).reshape(b, c, h, w)
        # print(af.shape)
        af = self.avgpoolf(af).reshape(b, -1)

        af = self.head(af)

        # print(af.shape)
        if flag:
            return af
        else:
            return x,x1


class vgg19_twoModal_ModelNet(nn.Module):
    def __init__(self, channel=64):
        super(vgg19_twoModal_ModelNet, self).__init__()
        # Backbone model
        self.rgb = models.vgg19(num_classes=6,pretrained=False)  # True 64, 128, 320, 512
        self.rgb1 = models.vgg19(num_classes=6, pretrained=False)  # True 64, 128, 320, 512

        self.MCSM = nn.MultiheadAttention(512, 8)
        self.MCSM1 = nn.MultiheadAttention(512, 8)

        self.avgpoolf = nn.AdaptiveAvgPool2d((1, 1))
        self.head = nn.Linear(512, 6)
        #self.rgb.init_weights("/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/segformer/pretrained/mit_b4.pth")
        #path = "/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/resnet152-b121ed2d.pth"
        #self.rgb.load_state_dict(torch.load(path, map_location='cuda:0'))

        # Components of DEM module
        # self.atten_depth_channel_1 = ChannelAttention(64)
        # self.atten_depth_channel_2 = ChannelAttention(128)
        # self.atten_depth_channel_3_1 = ChannelAttention(256)
        # self.atten_depth_channel_4_1 = ChannelAttention(512)
        #
        # self.atten_depth_spatial_1 = SpatialAttention()
        # self.atten_depth_spatial_2 = SpatialAttention()
        # self.atten_depth_spatial_3_1 = SpatialAttention()
        # self.atten_depth_spatial_4_1 = SpatialAttention()
        #
        # self.conv1_1=nn.Conv2d(512, 1,kernel_size=1, stride=1, bias=False)

    def forward(self, x,x1):

        # x = self.rgb.forward_features(x)
        x = self.forward_features(x,x1)
        #print(rgb_depth[0].shape)

        # x1 = x[0]
        #
        # sx1, sx1_depth = nn.Sigmoid()(sx1),nn.Sigmoid()(sx1_depth)
        #
        # x2 = x[1]
        #
        # sx2, sx2_depth = nn.Sigmoid()(sx2), nn.Sigmoid()(sx2_depth)
        #
        # x3_1 = x[2]
        # sx3, sx3_depth = nn.Sigmoid()(sx3), nn.Sigmoid()(sx3_depth)
        #
        #
        # x4_1 = x[3]
        # sx4, sx4_depth = nn.Sigmoid()(sx4), nn.Sigmoid()(sx4_depth)
        #
        #
        # #x = x + temp0
        # x1_1 = sx1*x1 + sx1_depth*x1_depth
        # x2_1 = sx2*x2 + sx2_depth*x2_depth
        # x3_1 = sx3*x3_1 + sx3_depth*x3_1_depth
        # x4_1 = sx4*x4_1 + sx4_depth*x4_1_depth
        # x4_2 = self.rfb4_1(x4_1)
        #
        # # produce final saliency map by decoder2
        # y = self.agg1(x4_2,x4_1,x3_1,x2_1, x1_1)

        return x
    def forward_features(self,x,x1,flag=True):
        x = self.rgb.features(x)
        x1 = self.rgb1.features(x1)
        b, c, h, w = x.shape
        #print(b,c,h,w)
        a, aw = self.MCSM(x.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1))
        a1, aw1 = self.MCSM1(x1.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1))
        af = a + a1

        af = af.permute(0, 2, 1).reshape(b, c, h, w)
        # print(af.shape)
        af = self.avgpoolf(af).reshape(b, -1)

        af = self.head(af)

        # print(af.shape)
        if flag:
            return af
        else:
            return x, x1


class convnext_large_twoModal_ModelNet(nn.Module):
    def __init__(self, channel=64):
        super(convnext_large_twoModal_ModelNet, self).__init__()
        # Backbone model
        self.rgb = models.convnext_large(num_classes=6,pretrained=False)  # True 64, 128, 320, 512
        self.rgb1 = models.convnext_large(num_classes=6, pretrained=False)  # True 64, 128, 320, 512

        self.MCSM = nn.MultiheadAttention(1536, 8)
        self.MCSM1 = nn.MultiheadAttention(1536, 8)

        self.avgpoolf = nn.AdaptiveAvgPool2d((1, 1))
        self.head = nn.Linear(1536, 6)

        #self.rgb.init_weights("/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/segformer/pretrained/mit_b4.pth")
        #path = "/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/resnet152-b121ed2d.pth"
        #self.rgb.load_state_dict(torch.load(path, map_location='cuda:0'))

        # Components of DEM module
        # self.atten_depth_channel_1 = ChannelAttention(64)
        # self.atten_depth_channel_2 = ChannelAttention(128)
        # self.atten_depth_channel_3_1 = ChannelAttention(256)
        # self.atten_depth_channel_4_1 = ChannelAttention(512)
        #
        # self.atten_depth_spatial_1 = SpatialAttention()
        # self.atten_depth_spatial_2 = SpatialAttention()
        # self.atten_depth_spatial_3_1 = SpatialAttention()
        # self.atten_depth_spatial_4_1 = SpatialAttention()
        #
        # self.conv1_1=nn.Conv2d(512, 1,kernel_size=1, stride=1, bias=False)

    def forward(self, x,x1):

        # x = self.rgb.forward_features(x)
        x = self.rgb.features(x)
        x1 = self.rgb1.features(x1)

        b, c, h, w = x.shape
        # print(b,c,h,w)
        a, aw = self.MCSM(x.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1))
        a1, aw1 = self.MCSM1(x1.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1))
        af = a + a1

        af = af.permute(0, 2, 1).reshape(b, c, h, w)
        # print(af.shape)
        af = self.avgpoolf(af).reshape(b, -1)

        af = self.head(af)

        # print(af.shape)
        return af

    def forward_features(self,x,x1):
         x = self.rgb.features(x)
         x1 = self.rgb1.features(x1)
         return x,x1


class swin_b_twoModal_ModelNet(nn.Module):
    def __init__(self, channel=64):
        super(swin_b_twoModal_ModelNet, self).__init__()
        # Backbone model
        self.rgb = models.swin_b(num_classes=6)  # True 64, 128, 320, 512
        self.rgb1 = models.swin_b(num_classes=6)  # True 64, 128, 320, 512

        self.MCSM = nn.MultiheadAttention(1024, 8)
        self.MCSM1 = nn.MultiheadAttention(1024, 8)

        self.avgpoolf = nn.AdaptiveAvgPool2d((1, 1))
        self.head = nn.Linear(1024, 6)

        #self.rgb.init_weights("/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/segformer/pretrained/mit_b4.pth")
        #path = "/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/resnet152-b121ed2d.pth"
        #self.rgb.load_state_dict(torch.load(path, map_location='cuda:0'))

        # Components of DEM module
        # self.atten_depth_channel_1 = ChannelAttention(64)
        # self.atten_depth_channel_2 = ChannelAttention(128)
        # self.atten_depth_channel_3_1 = ChannelAttention(256)
        # self.atten_depth_channel_4_1 = ChannelAttention(512)
        #
        # self.atten_depth_spatial_1 = SpatialAttention()
        # self.atten_depth_spatial_2 = SpatialAttention()
        # self.atten_depth_spatial_3_1 = SpatialAttention()
        # self.atten_depth_spatial_4_1 = SpatialAttention()
        #
        # self.conv1_1=nn.Conv2d(512, 1,kernel_size=1, stride=1, bias=False)

    def forward(self, x,x1):

        # x = self.rgb.forward_features(x)
        x = self.rgb.features(x)
        x1 = self.rgb1.features(x1)
        #print(x.shape)



        #print(rgb_depth[0].shape)

        # x1 = x[0]
        #
        # sx1, sx1_depth = nn.Sigmoid()(sx1),nn.Sigmoid()(sx1_depth)
        #
        # x2 = x[1]
        #
        # sx2, sx2_depth = nn.Sigmoid()(sx2), nn.Sigmoid()(sx2_depth)
        #
        # x3_1 = x[2]
        # sx3, sx3_depth = nn.Sigmoid()(sx3), nn.Sigmoid()(sx3_depth)
        #
        #
        # x4_1 = x[3]
        # sx4, sx4_depth = nn.Sigmoid()(sx4), nn.Sigmoid()(sx4_depth)
        #
        #
        # #x = x + temp0
        # x1_1 = sx1*x1 + sx1_depth*x1_depth
        # x2_1 = sx2*x2 + sx2_depth*x2_depth
        # x3_1 = sx3*x3_1 + sx3_depth*x3_1_depth
        # x4_1 = sx4*x4_1 + sx4_depth*x4_1_depth
        # x4_2 = self.rfb4_1(x4_1)
        #
        # # produce final saliency map by decoder2
        # y = self.agg1(x4_2,x4_1,x3_1,x2_1, x1_1)


        x=x.permute(0,3,1,2)
        x1 = x1.permute(0, 3, 1, 2)

        b, c, h, w = x.shape
        # print(b,c,h,w)
        a, aw = self.MCSM(x.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1))
        a1, aw1 = self.MCSM1(x1.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1))
        af = a + a1

        af = af.permute(0, 2, 1).reshape(b, c, h, w)
        # print(af.shape)
        af = self.avgpoolf(af).reshape(b, -1)

        af = self.head(af)

        # print(af.shape)
        return af


    def forward_features(self,x,x1):
         x = self.rgb.features(x)
         x1 = self.rgb1.features(x1)
         return x,x1



class vit_b_32_twoModal_ModelNet(nn.Module):
    def __init__(self, channel=64):
        super(vit_b_32_twoModal_ModelNet, self).__init__()
        # Backbone model
        self.rgb = models.vit_b_32(num_classes=6)  # True 64, 128, 320, 512
        self.rgb1 = models.vit_b_32(num_classes=6)  # True 64, 128, 320, 512

        self.MCSM = nn.MultiheadAttention(768, 8)
        self.MCSM1 = nn.MultiheadAttention(768, 8)

        self.avgpoolf = nn.AdaptiveAvgPool2d((1, 1))
        self.head = nn.Linear(768, 6)

        #self.rgb.init_weights("/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/segformer/pretrained/mit_b4.pth")
        #path = "/home/wby/Desktop/classify/toolbox/models/segFormer_ModelNet/resnet152-b121ed2d.pth"
        #self.rgb.load_state_dict(torch.load(path, map_location='cuda:0'))

        # Components of DEM module
        # self.atten_depth_channel_1 = ChannelAttention(64)
        # self.atten_depth_channel_2 = ChannelAttention(128)
        # self.atten_depth_channel_3_1 = ChannelAttention(256)
        # self.atten_depth_channel_4_1 = ChannelAttention(512)
        #
        # self.atten_depth_spatial_1 = SpatialAttention()
        # self.atten_depth_spatial_2 = SpatialAttention()
        # self.atten_depth_spatial_3_1 = SpatialAttention()
        # self.atten_depth_spatial_4_1 = SpatialAttention()
        #
        # self.conv1_1=nn.Conv2d(512, 1,kernel_size=1, stride=1, bias=False)

    def forward(self, x,x1):

        x = self.rgb._process_input(x)
        n = x.shape[0]

        # Expand the class token to the full batch
        batch_class_token = self.rgb.class_token.expand(n, -1, -1)
        x = torch.cat([batch_class_token, x], dim=1)

        x = self.rgb.encoder(x)
        #print(x.shape)
        x = x.permute(0, 2,1).reshape(n,768,10,5)
        #print(x.shape)

        x1 = self.rgb1._process_input(x1)
        n1 = x1.shape[0]
        # Expand the class token to the full batch
        batch_class_token1 = self.rgb1.class_token.expand(n1, -1, -1)
        x1 = torch.cat([batch_class_token1, x1], dim=1)

        x1 = self.rgb1.encoder(x1)
        x1= x1.permute(0, 2, 1).reshape(n1, 768, 10, 5)

        #print(rgb_depth[0].shape)

        #x = x.permute(0, 3, 1, 2)
        #x1 = x1.permute(0, 3, 1, 2)

        b, c, h, w = x.shape
        #print(b,c,h,w)
        a, aw = self.MCSM(x.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1),
                          x1.reshape(b, c, h * w).permute(0, 2, 1))
        a1, aw1 = self.MCSM1(x1.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1),
                             x.reshape(b, c, h * w).permute(0, 2, 1))
        af = a + a1

        af = af.permute(0, 2, 1).reshape(b, c, h, w)
        # print(af.shape)
        af = self.avgpoolf(af).reshape(b, -1)

        af = self.head(af)

        # print(af.shape)
        return af


    def forward_features(self,x,x1):
        x = self.rgb._process_input(x)
        n = x.shape[0]

        # Expand the class token to the full batch
        batch_class_token = self.rgb.class_token.expand(n, -1, -1)
        x = torch.cat([batch_class_token, x], dim=1)

        x = self.rgb.encoder(x)
        # print(x.shape)
        x = x.permute(0, 2, 1).reshape(n, 768, 10, 5)
        # print(x.shape)

        x1 = self.rgb1._process_input(x1)
        n1 = x1.shape[0]
        # Expand the class token to the full batch
        batch_class_token1 = self.rgb1.class_token.expand(n1, -1, -1)
        x1 = torch.cat([batch_class_token1, x1], dim=1)

        x1 = self.rgb1.encoder(x1)
        x1 = x1.permute(0, 2, 1).reshape(n1, 768, 10, 5)
        return x,x1



if __name__ == '__main__':
    img=torch.rand(2,3,224,224)
    model=vit_b_32_twoModal_ModelNet()
    from thop import profile

    flops, params = profile(model, (img, img))
    print('flops:%.2f G ,params:%.2f M' % (flops / 1000000000.0, params / 1000000.0))
    #print(model(img,img).shape)