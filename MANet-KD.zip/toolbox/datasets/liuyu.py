import os
from PIL import Image
import numpy as np
# from sklearn.model_selection import train_test_split

import torch
import torch.utils.data as data
from torchvision import transforms
from toolbox.datasets.augmentations import Resize, Compose, ColorJitter, RandomHorizontalFlip, RandomCrop, RandomScale, \
    RandomRotation


class Liuyu(data.Dataset):

    def __init__(self, cfg, mode='trainval', do_aug=True):

        assert mode in ['train', 'val', 'trainval', 'test', 'test_day', 'test_night'], f'{mode} not support.'
        self.mode = mode

        ## pre-processing 数据集图片的预处理
        # 定于转换方式，将几个操作组合起来
        self.im_to_tensor = transforms.Compose([
            # 归一化到(0,1)
            transforms.ToTensor(),
            # nb到(-1,1)
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])


        # 数据集所在目录
        self.root = cfg['root']
        self.n_classes = cfg['n_classes']

        scale_range = tuple(float(i) for i in cfg['scales_range'].split(' '))
        # 裁切尺寸
        crop_size = tuple(int(i) for i in cfg['crop_size'].split(' '))

        self.aug = Compose([
            ColorJitter(
                # 亮度
                brightness=cfg['brightness'],
                # 对比度
                contrast=cfg['contrast'],
                # 饱和度
                saturation=cfg['saturation']),
            # 依据概率p对图片进行水平翻转
            RandomHorizontalFlip(cfg['p']),
            RandomScale(scale_range),
            # 依据给定size随机剪裁
            RandomCrop(crop_size, pad_if_needed=True)
        ])

        self.val_resize = Resize(crop_size)

        # 解开封禁
        # self.val_resize = Resize(crop_size)

        self.mode = mode
        self.do_aug = do_aug
        self.secondLabel=[]

        self.infos = []
        self.infos1 = []
        # # 读取训练集测试集目录
        # with open(os.path.join(self.root, f'{mode}.txt'), 'r') as f:
        #     self.infos = f.readlines()
        #print('111',os.path.join(self.root, f'{mode}/'))
        Classifys=os.listdir(os.path.join(self.root, ''))
        # if mode=='train':
        #     Classifys.extend(os.listdir(os.path.join(self.root, 'test/')))
        if mode == 'train':
            rangePics = range(800 // 2)[:390]
        else:
            rangePics = range(800 // 2)[360:]
        for everyClassify in Classifys:
            tempFilenames=os.listdir(os.path.join(self.root, '',everyClassify))
            for tempFilename in rangePics:
                self.infos.append(os.path.join(self.root, ''+everyClassify+'/'+str(tempFilename+1)+"_a.png"))
                self.infos1.append(os.path.join(self.root, '' + everyClassify +'/'+str(tempFilename+1)+"_b.png"))
                self.secondLabel.append(everyClassify)
                print(os.path.join(os.path.join(self.root, ''+everyClassify+'/'+str(tempFilename+1)+"_a.png")))
        self.labelsName=Classifys
        print('labels:',self.labelsName)
    def __len__(self):
        return len(self.infos)

    def __getitem__(self, index):
        image_path = self.infos[index].strip()
        image = Image.open(image_path).convert("RGB")

        image_path1 = self.infos1[index].strip()
        image1 = Image.open(image_path1).convert("RGB")

        sample = {
            'image': image,
            'image1': image1
        }
        #if self.mode in ['test']:
        sample = self.val_resize(sample)

        if self.mode in ['train', 'trainval'] and self.do_aug:  # 只对训练集增强
            sample = self.aug(sample)

        #for i in in self.secondLabel)):
            #if self.labelsName[i] in image_path:
                #print(image_path)
        sample['label']=int(self.secondLabel[index])
        sample['path']=image_path
        sample['path1'] = image_path1
                #break

        sample['image'] = self.im_to_tensor(sample['image'])
        sample['image1'] = self.im_to_tensor(sample['image1'])
        return sample



if __name__ == '__main__':
    import json
    path = '/home/wby/Desktop/classify/configs/liuyu.json'
    with open(path, 'r') as fp:
        cfg = json.load(fp)
    dataset = Liuyu(cfg, mode='train', do_aug=True)
    print(len(dataset),dataset[20]["path"].split("/")[-1])