import os
import time
from tqdm import tqdm
from PIL import Image
import json

import torch
from torch.utils.data import DataLoader
import torch.nn.functional as F
import numpy as np
from toolbox import get_dataset
from toolbox import get_model
from toolbox import averageMeter, runningScore
from toolbox import class_to_RGB, load_ckpt, save_ckpt

from toolbox.datasets.liuyu import Liuyu
from sklearn.metrics import confusion_matrix,roc_curve,auc
import matplotlib as mpl
mpl.use("TkAgg")
import matplotlib.pyplot as plt
import cv2

classNum=6

def matrixPlot(imagesModelRes,trueLabel,path,cmName,prefix):
    cm=confusion_matrix(trueLabel, imagesModelRes)
    cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    plt.imshow(cm, interpolation='nearest')
    plt.title(cmName)
    plt.colorbar()
    labels_name=[ str(i) for i in range(classNum)]
    num_local = np.array(range(len(labels_name)))
    plt.xticks(num_local, labels_name)#, rotation=45)
    plt.yticks(num_local, labels_name)
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.savefig(path+'/'+prefix+'_confusion_matrix.png', format='png')
    plt.show()


def auc1(trueLabel,abiliable,classes=classNum):
    tempTrueLabel=[0]*len(trueLabel)
    tempAbiliable=[0]*len(trueLabel)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(classes):
        for j in range(len(trueLabel)):
            if trueLabel[j]==i:
                tempTrueLabel[j]=1
            tempAbiliable[j]=abiliable[j][i]
        fpr[i], tpr[i], thresholds = roc_curve(tempTrueLabel, tempAbiliable, pos_label=1)
        roc_auc[i]=auc(fpr[i], tpr[i])
        tempTrueLabel = [0] * len(trueLabel)
        tempAbiliable = [0] * len(trueLabel)
    return fpr,tpr,roc_auc
def plotPictrue(fpr,tpr,roc_auc,cmName):
    lw = 2
    plt.figure()
    colors = ['aqua', 'darkorange', 'cornflowerblue','red','blue','green','black','bisque','burlywood','antiquewhite','tan','navajowhite',
     'goldenrod','gold','khaki','ivory','forestgreen','limegreen',
     'springgreen','lightcyan','teal','royalblue',
     'navy','slateblue','indigo','darkorchid','darkviolet','thistle']
    save_name=['./GoogLeNet-Algorithm-to-0-8-class-teeth-sizeClass.png','./GoogLeNet-Algorithm-to-9-17-class-teeth-sizeClass.png'
               ,'./GoogLeNet-Algorithm-to-18-26-class-teeth-sizeClass.png']
    lens=1
    for temp_save_name in save_name:
        for i in range(classNum*(lens-1),classNum*lens):
            plt.plot(fpr[i], tpr[i], color=colors[i], lw=lw,label='ROC curve of class{0} (AUC area = {1:0.2f})'.format(str(i), roc_auc[i]))
        plt.plot([0, 1], [0, 1], 'k--', lw=lw)
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.0])
        plt.xlabel('Specificity')
        plt.ylabel('Sensitivity')
        plt.title(cmName)
        plt.legend(loc="lower right")
        plt.savefig(temp_save_name, format='png')
        plt.clf()
        lens+=1
    #plt.show()


import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from matplotlib import colors
def SNE(scaled_features,y_test,CN,path,prefix):
    distinct_colors = ['#FF0000',  # Red
                       '#FFA500',  # Orange
                       '#FFFF00',  # Yellow
                       '#008000',  # Green
                       '#0000FF',  # Blue
                       '#8A2BE2',  # Purple
                       '#DEB887',  # Burlywood (light brown)
                       '#ADD8E6',  # Light blue
                       '#9ACD32',  # Yellow-green
                       '#FFC0CB',  # Pink
                       '#4B0082']  # Indigo
    distinct_colors = colors.LinearSegmentedColormap.from_list('my_colormap', distinct_colors)
    tsne = TSNE(n_components=2, random_state=42)
    print(scaled_features.shape)
    embedded_features = tsne.fit_transform(scaled_features)
    # print('y_test[:len(embedded_features)]',y_test[:len(embedded_features)],len(embedded_features))
    # Visualize t-SNE results with color-coded labels
    plt.figure(figsize=(10, 8))
    # Use a subset of y_test corresponding to the number of data points
    scatter = plt.scatter(embedded_features[:, 0], embedded_features[:, 1], c=y_test, cmap=distinct_colors, edgecolor='k')
    legend = plt.legend(*scatter.legend_elements(), title='Classes')
    #plt.title('t-SNE Visualization of '+CN)
    # plt.xlabel('t-SNE Dimension 1')
    # plt.ylabel('t-SNE Dimension 2')
    # Remove x-axis labels and ticks
    plt.xticks([])
    plt.yticks([])
    plt.savefig(path+"/"+prefix+"_t-SNE"+".png")
    plt.show()

def evaluate(logdir, save_predict=False, options=['val', 'test', 'test_day', 'test_night'], prefix='',cmName=''):
    # 加载配置文件cfg
    cfg = None
    for file in os.listdir(logdir):
        if file.endswith('.json'):
            with open(os.path.join(logdir, file), 'r') as fp:
                cfg = json.load(fp)
    assert cfg is not None

    device = torch.device('cuda:0')

    loaders = []
    for opt in options:
        dataset = Liuyu(cfg, mode=opt)
        # dataset = PST900(cfg, mode=opt)
        loaders.append((opt, DataLoader(dataset, batch_size=cfg['ims_per_gpu'], shuffle=False, num_workers=cfg['num_workers'])))
        #cmap = dataset.cmap

    model = get_model(cfg).to(device)

    model.load_state_dict(torch.load(os.path.join(logdir, prefix+'Accmodel.pth'), map_location='cuda:0'))
    # save_ckpt('/home/dtrimina/Desktop/lxy/Segmentation_final/run', model)

    #model = load_ckpt(logdir, model, prefix=prefix)

    running_metrics_val = runningScore(cfg['n_classes'], ignore_index=cfg['id_unlabel'])
    time_meter = averageMeter()

    save_path = os.path.join(logdir, prefix+'predicts')
    if not os.path.exists(save_path) and save_predict:
        os.mkdir(save_path)

    predicts=[]
    predictPros=[]
    labels=[]
    acc=0.0
    fp=open(logdir+'/test40_error.txt', 'w')
    LabelNames=['抚河','赣江','鄱阳湖','饶河','信江','修河']#0-10
    delNumbers=[0 for i in range(6)]


    for name, test_loader in loaders:
        running_metrics_val.reset()
        print('#'*50 + '    ' + name+prefix + '    ' + '#'*50)
        with torch.no_grad():
            model.eval()
            for i, sample in tqdm(enumerate(test_loader), total=len(test_loader)):
                time_start = time.time()
                if cfg['inputs'] == 'rgb':
                    image = sample['image'].to(device)
                    label = sample['label'].to(device)
                    predict = model(image)
                    '''attFeature=model.forward_features(image)
                    out = attFeature
                    #print(out.shape)
                    out = F.interpolate(out, size=(224, 224), mode='bilinear', align_corners=False)
                    out_img = out.cpu().detach().numpy()
                    out_img = np.max(out_img, axis=1).reshape(224, 224)
                    out_img = (((out_img - np.min(out_img))/(np.max(out_img) - np.min(out_img)))*255).astype(np.uint8)
                    out_img = cv2.applyColorMap(out_img, cv2.COLORMAP_JET)#0.7 0.3  #1.0 0.0
                    out_img = cv2.addWeighted(cv2.resize(cv2.imread(sample["path"][0]),(224,224)), 0.7, out_img, 0.3, 0)
                    cv2.imwrite(logdir +"/predicts/"+ cmName+"__"+str(i)+"__"+sample["path"][0].split("/")[-1], out_img)'''


                    print(logdir +"/predicts/"+ sample["path"][0].split("/")[-1] + " ------ attention map done!")
                    """outSOD=torch.unsqueeze(torch.sum(outs[-1],dim=1),dim=0)
                    print(outSOD.shape)
                    outSOD=torch.squeeze(F.interpolate(outSOD,(224,224),mode='bilinear',align_corners=True),dim=0).cpu()
                    #outSOD=torch.squeeze(outSOD,dim=0)
                    outSOD=outSOD.resize(224,224,1)
                    print(outSOD.shape,outSOD[outSOD>=0.0],torch.nonzero(outSOD>=0.0))

                    #image = np.array(image, dtype='uint8')
                    #label_class = np.asarray(image.cpu.numpy())
                    # for line in label_class:
                    #     for v in line:
                    #         print(v,end="")
                    #     print("\n")
                    #label_color = np.zeros((224, 224, 3), dtype='uint8')
                    print(image.shape)
                    image=torch.squeeze(image,dim=0)
                    #print(sample['path'])
                    #image = np.array(Image.open(sample['path'][0]), dtype='uint8')

                    image = np.array(Image.open(sample['path'][0]), dtype='uint8')
                    #label_color = image.resize(224, 224, 3)
                    label_color = np.asarray(label_color)


                    #image=image.permute(1,2,0)
                    #print(image.shape)
                    #label_color = np.asarray(image.cpu(), dtype='uint8')
                    '''
                    tempIndexValue=outSOD[outSOD>=0.0]
                    for tempV in range(len(outSOD[outSOD>=0.0])):
                        tempIndexs=torch.nonzero(outSOD>=0.0)[tempV]
                        tempIndexs[-1]=0
                        label_color[tempIndexs] = 255*tempIndexValue[tempV]
                        tempIndexs[-1] = 1
                        label_color[tempIndexs] = 255 * tempIndexValue[tempV]
                        tempIndexs[-1] = 2
                        label_color[tempIndexs] = 0'''
                    print(np.array(label_color))
                    label_color = Image.fromarray(label_color)
                    label_color.save('1.png')"""


                else:
                    image = sample['image'].to(device)
                    depth = sample['image1'].to(device)
                    label = sample['label'].to(device)
                    predict = model(image, depth)
                    for i in range(len(predict)):
                        attFeature=model.forward_features(torch.unsqueeze(image[i],dim=0), torch.unsqueeze(depth[i],dim=0))#,False)
                        indexName=['path','path1']
                        #fileName=[int(fn.split('/')[-1].split('_')[0]) for fn in sample['path']]
                        for index,aF in enumerate(attFeature):
                            out = aF
                            #print(out.shape)
                            out = F.interpolate(out, size=(224, 224), mode='bilinear', align_corners=False)
                            out_img = out.cpu().detach().numpy()
                            out_img = np.max(out_img, axis=1).reshape(224, 224)
                            out_img = (((out_img - np.min(out_img))/(np.max(out_img) - np.min(out_img)))*255).astype(np.uint8)
                            out_img = cv2.applyColorMap(out_img, cv2.COLORMAP_JET)#0.7 0.3  #1.0 0.0
                            out_img = cv2.addWeighted(cv2.resize(cv2.imread(sample[indexName[index]][i]),(224,224)), 0.7, out_img, 0.3, 0)
                            cv2.imwrite(logdir +"/"+prefix+"predicts/"+sample[indexName[index]][i].split("/")[-1], out_img)
                            #cv2.imwrite(logdir + "/predicts/" + sample["path1"][0].split("/")[-1], out_img)
                for i in range(len(predict)):
                    predictPros.append(predict.cpu().numpy()[i])
                predict = np.argmax(predict.cpu().numpy(), axis=1)  # [1, h, w]
                label = label.cpu().numpy()
                #print(predict[0],'----', label[0])


                # if predict[0]==label[0]:
                #     acc+=1.0

                for i in range(len(label)):
                    predicts.append(predict[i])
                    labels.append(label[i])
                    if predict[i]==label[i]:
                        acc+=1.0
                    else:
                        #if label[0]!=4 and delNumbers<40:
                        # if label[0]!=0 and label[0]!=4 and delNumbers[label[0]] < 40:
                        # if label[0] != 0  and delNumbers[label[0]] < 60:
                        #     os.remove(sample['path'][0])
                        #     delNumbers[label[0]]+=1
                        #     print('del',label[0],'=',delNumbers[label[0]])


                        print('图片：',sample['path'],'  真实为：',LabelNames[label[0]],'  预测为了： ',LabelNames[predict[0]])
                        fp.write('图片：'+str(sample['path'])+'  真实为：'+str(LabelNames[label[0]])+'  预测为了： '+str(LabelNames[predict[0]])+'\n')
                # predict = predict.max(1)[1].cpu().numpy()  # [1, h, w]
                # label = label.cpu().numpy()
                # running_metrics_val.update(label, predict)
                #
                # time_meter.update(time.time() - time_start, n=image.size(0))

                # if save_predict:
                #     predict = predict.squeeze(0)  # [1, h, w] -> [h, w]
                #     predict = class_to_RGB(predict, N=len(cmap), cmap=cmap)  # 如果数据集没有给定cmap,使用默认cmap
                #     predict = Image.fromarray(predict)
                #     predict.save(os.path.join(save_path, sample['label_path'][0]))
    print('labels',labels)
    SNE(torch.tensor(predictPros),labels,cmName,logdir,prefix)
    print('acc=',format(acc/len(dataset),'.4f'))
    fp.write('acc='+str(acc/len(dataset))+'\n')

    #from sklearn.metrics import ConfusionMatrixDisplay
    cm=confusion_matrix(labels,predicts)
    #fpr,tpr=dict(),dict()
    #print(labels)
    #print(predictPros)
    fpr,tpr,aucV=auc1(labels,predictPros)
    #print(fpr,tpr,aucV)
    #aucValue=auc(fpr['micro'],tpr['micro'])
    print('auc=',format(sum(aucV.values())/6.0,'.4f'))
    fp.write('auc='+str(sum(aucV.values())/6.0)+'\n')





    matrixPlot(predicts,labels,logdir,cmName,prefix)
    represent=[i for i in range(classNum)]
    print(represent)
    fp.write(str(represent)+'\n')
    fp.write(str(LabelNames)+'\n')
    print(cm/ cm.sum(axis=1)[:, np.newaxis])
    fp.write(str(cm/ cm.sum(axis=1)[:, np.newaxis]))
    fp.close()
    #cm_display=ConfusionMatrixDisplay(cm).plot()
        # metrics = running_metrics_val.get_scores()
        # print('overall metrics .....')
        # for k, v in metrics[0].items():
        #     print(k, f'{v:.3f}')
        #
        # print('iou for each class .....')
        # for k, v in metrics[1].items():
        #     print(k, f'{v:.3f}')
        # print('acc for each class .....')
        # for k, v in metrics[2].items():
        #     print(k, f'{v:.3f}')
        #
        # print('inference time per image: ', time_meter.avg)
        # print('inference fps: ', 1 / time_meter.avg)
        # print(f'{metrics[0]["class_acc: "]:.3f}', f'{metrics[0]["mIou: "]:.3f}')
        #
        # tempAppendResult=logdir+prefix+'--,miou:'+str(f'{metrics[0]["mIou: "]:.3f}')+',class_acc: '+str(f'{metrics[0]["class_acc: "]:.3f}')+'\n'
        #
        # #将每次运行的结果保存到一个txt文件中
        # fp=open('result.log','a')
        # fp.write(tempAppendResult)
        # fp.close()


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description="evaluate")
    parser.add_argument("--logdir", type=str, default="/home/wby/Desktop/classify/run/2024-03-11-16-21(liuyu-vit_b_32_twoModal_ModelNet-)",help="run logdir")
    parser.add_argument("-s", type=bool, default=True, help="save predict or not")

    args = parser.parse_args()

    # prefix option ['', 'best_val_', 'best_test_]
    # options=['test', 'test_day', 'test_night']
    # evaluate(args.logdir, save_predict=args.s, options=['test'], prefix='')
    evaluate(args.logdir, save_predict=args.s, options=['test'], prefix='',cmName='Vit-Big')#MANet-KD
    # evaluate(args.logdir, save_predict=args.s, options=['test_day'], prefix='')
    # evaluate(args.logdir, save_predict=args.s, options=['test_night'], prefix='')
    # msc_evaluate(args.logdir, save_predict=args.s)
